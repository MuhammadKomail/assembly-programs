See screenshot for working of this game.

Run it on emu8086